<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\Work\2023\Rigways\laravel-project\latest\rigways\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>