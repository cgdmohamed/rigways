flatpickr("#datepicker", {
    dateFormat: "Y-m-d",
    minDate: "2020-01",
});

luge.settings({smooth: {inertia: 0.1}})