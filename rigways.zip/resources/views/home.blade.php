@extends('dashboard')

@include('widgets.stats')